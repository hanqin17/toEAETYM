#include "DSP28x_Project.h"     // Include DSP2802x Headerfile and project include file
#include "Flash2833x_API_Library.h"
#include <stddef.h>
#include "string.h"
#include "stdlib.h"
#include "stdio.h"

#define FlashH 0x300000
#define FlashG 0x308000
#define FlashF 0x310000
#define FlashE 0x318000
#define FlashD 0x320000
#define FlashC 0x328000
#define FlashB 0x330000
#define FlashA 0x338000
Uint32 BeginAdress=FlashH;
inline void UserMain()
{
    (*(void(*)(void))BeginAdress)();
}
#define UserMain (void(*)(void))0x300000
FLASH_ST FlashStatus;
//unsigned char Erase_Once_Succ=0;

#define LED0 GpioDataRegs.GPBDAT.bit.GPIO58
#define LED1 GpioDataRegs.GPBDAT.bit.GPIO57
#define LED2 GpioDataRegs.GPBDAT.bit.GPIO48

#define LSPLK 37478400UL
#define UartBaud 115200UL

Uint16 UartBuf[2500];
Uint16 UartNum;
char BootFlag=0;
char DataFlag=0;
Uint16 TimeOut=0;

Uint32 BootTimeOut=100; //1s
Uint32 ProgAdress=0;
Uint16 DatNum;

__interrupt void uart_isr(void);
__interrupt void cpu_timer0_isr(void);


unsigned long P_RAM_Init;  /*��ram�õ�ָ��*/
#define RAM_LEN        0x001000
#define RAM_Start_ADD     0xC000
void Ram_Init(void)
{

    for(P_RAM_Init=0 ; P_RAM_Init < RAM_LEN ; P_RAM_Init = P_RAM_Init+2 )
    {
        if ((unsigned long *)(RAM_Start_ADD + P_RAM_Init) !=  &P_RAM_Init)
        {
            *(unsigned long *)(RAM_Start_ADD + P_RAM_Init) = 0;
        }

    }
    P_RAM_Init=0;
}

void FlashAPI_Init()
{
    EALLOW;
    Flash_CPUScaleFactor = SCALE_FACTOR;
    Flash_CallbackPtr = NULL;
    EDIS;
    //if(Flash_APIVersionHex() != 0x0201) asm("    ESTOP0");
    //if(Flash_APIVersion() != (float32)2.01) asm("    ESTOP0");
}

void InitGpio()
{
    EALLOW;
    // ���� SCIB ��������
    GpioCtrlRegs.GPAPUD.bit.GPIO9 = 0;   // ���� GPIO9 Ϊ SCITXDB
    GpioCtrlRegs.GPAPUD.bit.GPIO11 = 0;  // ���� GPIO11 Ϊ SCIRXDB
    // ���� SCIB ���ŵ������޶�ģʽΪ�첽
    GpioCtrlRegs.GPAQSEL1.bit.GPIO11 = 3;  // GPIO11 (SCIRXDB) ����Ϊ�첽����
    // ���� SCIB ��������
    GpioCtrlRegs.GPAMUX1.bit.GPIO9 = 2;   // ���� GPIO9 Ϊ SCITXDB
    GpioCtrlRegs.GPAMUX1.bit.GPIO11 = 2;  // ���� GPIO11 Ϊ SCIRXDB
    EDIS;
}

void InitUart()
{
    EALLOW;
    ScibRegs.SCIFFTX.all=0xE040;
    ScibRegs.SCIFFRX.all=0x6061;
    ScibRegs.SCIFFCT.all=0x0;      //fifo
    ScibRegs.SCICCR.all =0x0007;   // 1 stop bit,  No loopback // No parity,8 char bits,// async mode, idle-line protocol
    ScibRegs.SCICTL1.all =0x0003;  // enable TX, RX, internal SCICLK, // Disable RX ERR, SLEEP, TXWAKE
    ScibRegs.SCICTL2.all =0x0003;
    ScibRegs.SCICTL2.bit.TXINTENA =0;
    ScibRegs.SCICTL2.bit.RXBKINTENA =0;
    ScibRegs.SCIHBAUD =(LSPLK/UartBaud/8-1)>>8;
    ScibRegs.SCILBAUD =(LSPLK/UartBaud/8-1)&0xFF;
    ScibRegs.SCICTL1.all =0x0023;  // Relinquish SCI from Reset
    ScibRegs.SCIPRI.all=0;
    EDIS;
}



void InitBoot()
{
    DINT;
    InitSysCtrl();
    InitGpio();
    //CsmUnlock();
    InitPieCtrl();
    IER = 0x0000;// Disable CPU interrupts and clear all CPU interrupt flags:
    IFR = 0x0000;
    InitPieVectTable();
    EALLOW;
    PieVectTable.SCIRXINTB= &uart_isr;
    PieVectTable.TINT0 = &cpu_timer0_isr;
    PieCtrlRegs.PIECTRL.bit.ENPIE=1;
    PieCtrlRegs.PIEIER9.bit.INTx3=1;
    PieCtrlRegs.PIEIER9.bit.INTx4=1;
    InitUart();
    EDIS;
    InitCpuTimers();
    ConfigCpuTimer(&CpuTimer0, 150, 10000);//10ms
    CpuTimer0Regs.TCR.all = 0x4000; // Use write-only instruction to set TSS bit = 0
    IER=0X100;
    IER |= M_INT1;
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;

    //Ram_Init();
    //MemCopy(&Flash28_API_LoadStart, &Flash28_API_LoadEnd, &Flash28_API_RunStart);
    MemCopy(&RamfuncsLoadStart, &RamfuncsLoadEnd, &RamfuncsRunStart);

    //InitFlash();
    //FlashAPI_Init();
    EINT;   // Enable Global interrupt INTM
    ERTM;   // Enable Global realtime interrupt DBGM
}

void UartXmit(const char *ptr)
{
    while(*ptr!='\0')
    {
         while (ScibRegs.SCIFFTX.bit.TXFFST != 0) {}
         ScibRegs.SCITXBUF=*ptr;
         ptr++;
    }
    DELAY_US(250);
}

void BootConFig()
{
    //DINT;
    //IER = 0x0000;// Disable CPU interrupts and clear all CPU interrupt flags:
    //IFR = 0x0000;
    Ram_Init();
    MemCopy(&Flash28_API_LoadStart, &Flash28_API_LoadEnd, &Flash28_API_RunStart);
    InitFlash();
    FlashAPI_Init();
}

char Erase_Sec_Once(Uint16 Sector)
{
    char outflag = 0xff;
    DINT;
    if(SysCtrlRegs.PLLSTS.bit.MCLKSTS==0)outflag=Flash_Erase(Sector, &FlashStatus);
    EINT;
    return outflag;
}
/*
#pragma CODE_SECTION(UserMain,".USER_CODE")
int UserMain()
{
    UartXmit("��ʼ�û�����\r\n");
    while(1)
    {
        LED0=!LED0;
        DELAY_US(50000);
        LED1=!LED1;
        DELAY_US(50000);
        LED2=!LED2;
        DELAY_US(50000);
    }
}
*/


void ProcessDat()
{
    Uint16 i=0,dat=0;
    DatNum=UartNum-6;
    //for(i=0,i<DatNum;i++)
    while(1)
    {
        dat=((UartBuf[i+3]<<8)|(UartBuf[i+4]));
        UartBuf[i/2]=dat;
        i+=2;
        if(i>=DatNum)
        {
            DatNum/=2;
            break;
        }
    }
}

void ProgramDat()
{
    DINT;
    if(Flash_Program((Uint16 *)ProgAdress,(Uint16 *)UartBuf,DatNum,&FlashStatus)!=STATUS_SUCCESS) UartXmit("ProgramErro\r\n");
    else ProgAdress+=DatNum;
    EINT;
}

int main(void)
{
    InitBoot();
    LED0=1;
    memset(UartBuf,0,sizeof(UartBuf));
    UartNum=0;
    UartXmit("3.27-SystemStartOK\r\n");
    while(BootTimeOut)
    {
        if((UartBuf[UartNum-1]=='\n')&&(UartBuf[UartNum-2]=='\r'))
        {
            if(strncmp((const char*)&UartBuf[0],"BOOT",4)==0)
            {
                DataFlag=0;
                TimeOut=0;
                BootFlag=1;
                memset(UartBuf,0,sizeof(UartBuf));
                UartNum=0;
                BootTimeOut=0;
            }
        }
    }
    if(BootFlag)
    {
        Uint16 CRC=0;
        Uint16 i=0;
        LED0=1;DELAY_US(1);
        LED1=1;DELAY_US(1);
        LED2=1;DELAY_US(1);
        BootConFig();
        if(Erase_Sec_Once(SECTORH|SECTORG|SECTORF|SECTORE|SECTORD|SECTORC|SECTORB)!= STATUS_SUCCESS) UartXmit("EraseErro\r\n");
        else UartXmit("OK\r\n");
        while(1)
        {
            //if((UartBuf[UartNum-1]=='\n')&&(UartBuf[UartNum-2]=='\r'))
            if(TimeOut>=10)
            {
                DataFlag=0;
                TimeOut=0;
                if(strncmp((const char*)&UartBuf[0],"Adr",3)==0)
                {
                    for(i=3;i<UartNum-3;i++)CRC+=UartBuf[i];
                    CRC&=0xFF;
                    if(UartBuf[UartNum-3]==CRC)
                    {
                        ProgAdress=(((Uint32)UartBuf[3]<<16)|((Uint32)UartBuf[4]<<8)|((Uint32)UartBuf[5]));
                        memset(UartBuf,0,sizeof(UartBuf));
                        UartNum=0;
                        UartXmit("CheckOK\r\n");
                        CRC=0;
                    }
                    else
                    {
                        memset(UartBuf,0,sizeof(UartBuf));
                        UartNum=0;
                        UartXmit("CheckErro\r\n");
                        CRC=0;
                    }
                }
                else if(strncmp((const char*)&UartBuf[0],"Dat",3)==0)
                {
                    for(i=3;i<UartNum-3;i++)CRC+=UartBuf[i];
                    CRC&=0xFF;
                    if(UartBuf[UartNum-3]==CRC)
                    {
                        ProcessDat();
                        ProgramDat();
                        memset(UartBuf,0,sizeof(UartBuf));
                        UartNum=0;
                        UartXmit("CheckOK\r\n");
                        CRC=0;
                    }
                    else
                    {
                        memset(UartBuf,0,sizeof(UartBuf));
                        UartNum=0;
                        UartXmit("CheckErro\r\n");
                        CRC=0;
                    }
                }
                else if(strncmp((const char*)&UartBuf[0],"End",3)==0)
                {
                    memset(UartBuf,0,sizeof(UartBuf));
                    UartNum=0;
                    EALLOW;
                    SysCtrlRegs.WDCR=((0<<6)|(0<<3)|(7<<0));
                    EDIS;
                }
            }
        }
    }
    else
    {
        (*UserMain)();
    }

}


__interrupt void uart_isr(void)
{
    UartBuf[UartNum]=ScibRegs.SCIRXBUF.bit.RXDT;
    UartNum++;
    DataFlag=1;
    TimeOut=0;
    PieCtrlRegs.PIEACK.all|=0x100;
    ScibRegs.SCIFFRX.bit.RXFFINTCLR=1;
    ScibRegs.SCIFFRX.bit.RXFFOVRCLR=1;
}
__interrupt void cpu_timer0_isr(void)   //0.01s
{
   if(BootTimeOut>0)BootTimeOut--;
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
   if(DataFlag==1)TimeOut++;
}
