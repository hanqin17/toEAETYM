#include "DSP28x_Project.h"		// Include DSP2802x Headerfile and project include file

void SCIa_Init();

// ==== SCIa_Init_AutoBaud ================================= 
void SCIa_Init_AutoBaud();

// ==== SCIa_FifoSend send 1 Byte data ===================
void SCIa_FifoSend(char *msg);

// ==== SCIa_GetByteData_app ============================
// Get 8 bits data from SCIa. Return {8'h00, Byte}.
Uint16 SCIa_GetByteData_app();

// ==== SCIa_Get16bitData ===============================
// Get 16 bits data from SCIa. The first letter is MSB.
Uint16 SCIa_Get16bitData();

// ==== SCIa_Get32bitData ===============================
// Get 32 bits data from SCIa. The first letter is MSB.:w
Uint32 SCIa_Get32bitData();

